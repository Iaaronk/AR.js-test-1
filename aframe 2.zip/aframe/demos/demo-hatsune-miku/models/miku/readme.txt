readme_miku_v2.txt: readme of MMD software for Hatsune Miku model

The Miku model in this directory is a bandle model of MMD software.

                                                       by takahiro
