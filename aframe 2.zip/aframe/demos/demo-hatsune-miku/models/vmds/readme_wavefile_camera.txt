﻿MikuMikuDance用カメラモーションデータ+おまけピンナップ

この度はDLしていただきありがとうございます(´∀｀)

ula式ミクさん　かっつりトゥーン　WAVEFILE　【MMD】
http://www.nicovideo.jp/watch/sm19168559


モデル：ula様　http://www.nicovideo.jp/user/3385769

曲：sm11938255：ラマーズP様

モーション：sm13147122：hino様

ステージ：NBBCM風ステージsm12424615：k9様/psg_stage

エフェクト

Diffusion・XDOF・AutoLuminous:そぼろ様
かっつりトゥーン：Less様
SSAO_Toon:ビームマンP様


こちらを使用したデータとなります。

注意点は特に無いです。フルVerではないのでご了承下さい。


動画に関わる方々、権利者の迷惑にならないようお願いします。

（R-18タグの動画には使用は禁止です。）

改変・改変後の再配布は可。好きにいじってくださいませ。


では、よきMMDライフを！


2012/11/08

doramata
